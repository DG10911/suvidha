import KioskLayout from "@/components/layout/KioskLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useLocation } from "wouter";
import { CheckCircle2, QrCode, ArrowRight, UserPlus, Fingerprint, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Signup() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<"aadhar" | "fetching" | "details" | "qr">("aadhar");
  const [aadhar, setAadhar] = useState("");

  const handleFetch = () => {
    if (aadhar.length === 12) {
      setStep("fetching");
      setTimeout(() => setStep("details"), 2000);
    }
  };

  const handleNumberClick = (num: string) => {
    if (aadhar.length < 12) setAadhar(prev => prev + num);
  };

  const handleBackspace = () => {
    setAadhar(prev => prev.slice(0, -1));
  };

  return (
    <KioskLayout>
      <div className="h-full flex flex-col items-center justify-center max-w-2xl mx-auto w-full">
        <AnimatePresence mode="wait">
          {step === "aadhar" && (
            <motion.div 
              key="aadhar"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full space-y-8"
            >
              <div className="text-center">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                  <Fingerprint className="w-10 h-10" />
                </div>
                <h2 className="text-4xl font-bold font-heading mb-2">Register with Aadhaar</h2>
                <p className="text-xl text-muted-foreground">Enter your 12-digit Aadhaar number to begin</p>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-lg border border-border">
                <Input 
                  readOnly
                  value={aadhar.replace(/(\d{4})/g, '$1 ').trim()}
                  className="text-center text-4xl font-mono py-8 h-24 tracking-widest rounded-xl border-2 border-primary/20 bg-secondary/30 mb-8"
                  placeholder="0000 0000 0000"
                />

                <div className="grid grid-cols-3 gap-4 mb-8">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                    <Button
                      key={num}
                      variant="outline"
                      className="h-20 text-3xl font-bold rounded-2xl hover:bg-primary/5 hover:border-primary transition-all"
                      onClick={() => handleNumberClick(num.toString())}
                    >
                      {num}
                    </Button>
                  ))}
                  <Button variant="ghost" className="h-20 text-xl font-medium rounded-2xl text-muted-foreground" onClick={() => setAadhar("")}>Clear</Button>
                  <Button
                    variant="outline"
                    className="h-20 text-3xl font-bold rounded-2xl hover:bg-primary/5 hover:border-primary transition-all"
                    onClick={() => handleNumberClick("0")}
                  >
                    0
                  </Button>
                  <Button variant="ghost" className="h-20 rounded-2xl text-destructive hover:bg-destructive/10" onClick={handleBackspace}>
                    Back
                  </Button>
                </div>

                <Button 
                  size="lg" 
                  className="w-full h-20 text-2xl rounded-2xl gap-3"
                  disabled={aadhar.length !== 12}
                  onClick={handleFetch}
                >
                  Verify & Fetch Details
                  <ArrowRight className="w-6 h-6" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === "fetching" && (
            <motion.div 
              key="fetching"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center gap-6"
            >
              <Loader2 className="w-16 h-16 text-primary animate-spin" />
              <div className="text-center">
                <h3 className="text-3xl font-bold font-heading">Fetching Details</h3>
                <p className="text-xl text-muted-foreground">Connecting to Aadhaar secure server...</p>
              </div>
            </motion.div>
          )}

          {step === "details" && (
            <motion.div 
              key="details"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="w-full space-y-6"
            >
              <div className="text-center mb-8">
                <h2 className="text-4xl font-bold font-heading">Confirm Your Details</h2>
                <p className="text-xl text-muted-foreground">Is this information correct?</p>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-lg border border-border space-y-6">
                <div className="flex items-center gap-6 pb-6 border-b">
                  <div className="w-24 h-24 bg-secondary rounded-2xl overflow-hidden flex items-center justify-center border-2 border-primary/20">
                     <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="Aadhar Face" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-2xl font-bold">Ramesh Kumar Sharma</h4>
                    <p className="text-muted-foreground text-lg">DOB: 15/05/1982</p>
                    <p className="text-muted-foreground text-lg">Gender: Male</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 text-lg">
                  <div>
                    <p className="text-muted-foreground text-sm uppercase tracking-wider font-bold">Permanent Address</p>
                    <p className="font-medium">H.No 42, Ward 15, Near City Park, Raipur, Chhattisgarh - 492001</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm uppercase tracking-wider font-bold">Mobile Linked</p>
                    <p className="font-medium">XXXXXX5621</p>
                  </div>
                </div>

                <Button 
                  size="lg" 
                  className="w-full h-20 text-2xl rounded-2xl mt-4"
                  onClick={() => setStep("qr")}
                >
                  Generate Permanent QR
                </Button>
              </div>
            </motion.div>
          )}

          {step === "qr" && (
            <motion.div 
              key="qr"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full space-y-8"
            >
              <div className="text-center">
                <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600">
                  <CheckCircle2 className="w-12 h-12" />
                </div>
                <h2 className="text-4xl font-bold font-heading">Registration Successful</h2>
                <p className="text-xl text-muted-foreground">Here is your Permanent Suvidha QR Code</p>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-xl border-4 border-primary/20 flex flex-col items-center gap-8 max-w-md mx-auto relative overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-2 bg-primary"></div>
                <div className="text-center">
                   <h3 className="text-2xl font-bold text-primary">SUVIDHA PASS</h3>
                   <p className="text-sm font-medium text-muted-foreground">Citizen ID: SUV-9921-X</p>
                </div>

                <div className="p-4 bg-white border-2 border-border rounded-2xl">
                  <QrCode className="w-48 h-48 text-foreground" />
                </div>

                <div className="text-center space-y-2">
                  <p className="font-bold text-lg">Ramesh Kumar Sharma</p>
                  <p className="text-muted-foreground">Scan this at any kiosk for instant login</p>
                </div>

                <div className="flex gap-4 w-full">
                   <Button variant="outline" className="flex-1 h-14 rounded-xl" onClick={() => window.print()}>Print Card</Button>
                   <Button className="flex-1 h-14 rounded-xl" onClick={() => setLocation("/dashboard")}>Go to Dashboard</Button>
                </div>
              </div>

              <p className="text-center text-muted-foreground">
                A digital copy has been sent to your linked mobile number.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </KioskLayout>
  );
}