import KioskLayout from "@/components/layout/KioskLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { CheckCircle2, ArrowRight, ArrowLeft, Camera, Upload } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const steps = ["Category", "Details", "Review", "Success"];

const subcategories = {
  electricity: ["Power Outage", "New Connection", "Billing Issue", "Meter Fault"],
  water: ["No Water", "Leakage", "Dirty Water", "Low Pressure"],
  gas: ["Cylinder Booking", "Leakage", "New Connection"],
  waste: ["Garbage Not Picked", "Street Sweeping", "Dead Animal"],
  infrastructure: ["Pothole", "Streetlight", "Drainage", "Park Maintenance"],
  complaints: ["Check Status", "Re-open Ticket"]
};

export default function ServiceRequest() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/service/:type");
  const type = (params?.type as keyof typeof subcategories) || "electricity";
  
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    category: "",
    description: "",
    urgency: "normal"
  });

  const nextStep = () => setCurrentStep(p => Math.min(steps.length - 1, p + 1));
  const prevStep = () => setCurrentStep(p => Math.max(0, p - 1));

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="grid grid-cols-2 gap-4">
            {subcategories[type]?.map((sub) => (
              <button
                key={sub}
                onClick={() => {
                  setFormData({ ...formData, category: sub });
                  nextStep();
                }}
                className={`p-6 rounded-2xl border-2 text-left text-xl font-medium transition-all ${
                  formData.category === sub 
                  ? "border-primary bg-primary/5 text-primary" 
                  : "border-border bg-white hover:border-primary/50"
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        );
      case 1:
        return (
          <div className="space-y-8 bg-white p-8 rounded-3xl border border-border">
            <div className="space-y-4">
              <Label className="text-xl">Describe the Issue</Label>
              <Textarea 
                placeholder="Please describe the problem in detail..." 
                className="min-h-[150px] text-lg p-4 rounded-xl border-2 focus-visible:ring-primary"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>
            
            <div className="space-y-4">
               <Label className="text-xl">Urgency Level</Label>
               <RadioGroup 
                 value={formData.urgency} 
                 onValueChange={(val) => setFormData({...formData, urgency: val})}
                 className="flex gap-4"
               >
                 <div className="flex items-center space-x-2 bg-secondary/50 p-4 rounded-xl flex-1 border-2 border-transparent data-[state=checked]:border-primary cursor-pointer">
                   <RadioGroupItem value="normal" id="r1" />
                   <Label htmlFor="r1" className="text-lg cursor-pointer">Normal</Label>
                 </div>
                 <div className="flex items-center space-x-2 bg-secondary/50 p-4 rounded-xl flex-1 border-2 border-transparent data-[state=checked]:border-orange-500 cursor-pointer">
                   <RadioGroupItem value="high" id="r2" />
                   <Label htmlFor="r2" className="text-lg cursor-pointer">High</Label>
                 </div>
                 <div className="flex items-center space-x-2 bg-secondary/50 p-4 rounded-xl flex-1 border-2 border-transparent data-[state=checked]:border-destructive cursor-pointer">
                   <RadioGroupItem value="emergency" id="r3" />
                   <Label htmlFor="r3" className="text-lg cursor-pointer text-destructive font-bold">Emergency</Label>
                 </div>
               </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-xl">Evidence (Optional)</Label>
              <div className="flex gap-4">
                <Button variant="outline" className="h-24 flex-1 rounded-xl gap-2 text-lg border-2 border-dashed">
                  <Camera className="w-8 h-8" />
                  Take Photo
                </Button>
                <Button variant="outline" className="h-24 flex-1 rounded-xl gap-2 text-lg border-2 border-dashed">
                  <Upload className="w-8 h-8" />
                  Upload File
                </Button>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6 bg-white p-8 rounded-3xl border border-border">
            <h3 className="text-2xl font-bold">Summary</h3>
            <div className="grid grid-cols-2 gap-6 text-lg">
              <div>
                <p className="text-muted-foreground">Service Type</p>
                <p className="font-medium capitalize">{type}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Category</p>
                <p className="font-medium">{formData.category}</p>
              </div>
              <div className="col-span-2">
                <p className="text-muted-foreground">Description</p>
                <p className="font-medium">{formData.description || "No description provided"}</p>
              </div>
               <div>
                <p className="text-muted-foreground">Urgency</p>
                <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold uppercase ${
                  formData.urgency === 'emergency' ? 'bg-destructive/10 text-destructive' : 
                  formData.urgency === 'high' ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'
                }`}>
                  {formData.urgency}
                </span>
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="flex flex-col items-center justify-center py-12 space-y-8 text-center bg-white rounded-3xl border border-border">
            <div className="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center text-green-600">
              <CheckCircle2 className="w-16 h-16" />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-2">Complaint Registered!</h2>
              <p className="text-xl text-muted-foreground">Your Complaint ID is <span className="font-mono font-bold text-foreground">#SUV-2024-8892</span></p>
            </div>
            <div className="p-4 bg-secondary/50 rounded-xl max-w-md">
              <p className="text-lg">You will receive SMS updates on your registered mobile number.</p>
            </div>
            <div className="flex gap-4 w-full max-w-md px-8">
              <Button className="flex-1 h-14 text-lg rounded-xl" onClick={() => setLocation("/dashboard")}>
                Go to Dashboard
              </Button>
              <Button variant="outline" className="flex-1 h-14 text-lg rounded-xl" onClick={() => window.print()}>
                Print Receipt
              </Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <KioskLayout>
      <div className="h-full flex flex-col max-w-4xl mx-auto w-full">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {steps.map((stepName, idx) => (
              <span key={idx} className={`text-sm font-bold uppercase tracking-wider ${idx <= currentStep ? "text-primary" : "text-muted-foreground"}`}>
                {stepName}
              </span>
            ))}
          </div>
          <div className="h-3 bg-secondary rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-primary"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        <div className="flex-1">
          <div className="mb-6">
            <h2 className="text-3xl font-bold font-heading capitalize">
              {currentStep === 3 ? "Submission Complete" : `New ${type} Request`}
            </h2>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {renderStepContent()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Action Buttons */}
        {currentStep < 3 && (
          <div className="flex justify-between pt-8 mt-auto">
             <Button 
                variant="outline" 
                size="lg" 
                className="h-16 px-8 text-xl rounded-2xl gap-2"
                onClick={prevStep}
                disabled={currentStep === 0}
              >
                <ArrowLeft className="w-6 h-6" />
                Back
              </Button>

             <Button 
                size="lg" 
                className="h-16 px-12 text-xl rounded-2xl gap-2 shadow-lg shadow-primary/20"
                onClick={currentStep === 2 ? nextStep : nextStep}
                disabled={currentStep === 0 && !formData.category} // Disable next if no category selected (though clicking button does it)
              >
                {currentStep === 2 ? "Submit Complaint" : "Next Step"}
                <ArrowRight className="w-6 h-6" />
              </Button>
          </div>
        )}
      </div>
    </KioskLayout>
  );
}