import KioskLayout from "@/components/layout/KioskLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { ArrowRight, Smartphone, QrCode, Delete } from "lucide-react";
import { motion } from "framer-motion";

export default function Login() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/login/:method");
  const method = params?.method || "mobile";
  
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"phone" | "otp">("phone");

  const handleNumberClick = (num: string) => {
    if (step === "phone") {
      if (phoneNumber.length < 10) setPhoneNumber(prev => prev + num);
    } else {
      if (otp.length < 6) setOtp(prev => prev + num);
    }
  };

  const handleBackspace = () => {
    if (step === "phone") {
      setPhoneNumber(prev => prev.slice(0, -1));
    } else {
      setOtp(prev => prev.slice(0, -1));
    }
  };

  const handleSubmit = () => {
    if (step === "phone") {
      if (phoneNumber.length === 10) setStep("otp");
    } else {
      if (otp.length === 6) setLocation("/dashboard");
    }
  };

  return (
    <KioskLayout>
      <div className="h-full flex flex-col items-center justify-center max-w-2xl mx-auto w-full">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold font-heading mb-2">
            {method === "qr" ? "Scan QR Code" : "Login with Mobile"}
          </h2>
          <p className="text-xl text-muted-foreground">
            {method === "qr" 
              ? "Scan the QR code from your Suvidha mobile app" 
              : step === "phone" ? "Enter your 10-digit mobile number" : "Enter the 6-digit OTP sent to your mobile"
            }
          </p>
        </div>

        {method === "mobile" ? (
          <div className="w-full bg-white p-8 rounded-3xl shadow-lg border border-border">
            <div className="mb-8">
              <Input 
                readOnly
                value={step === "phone" ? phoneNumber : otp}
                className="text-center text-4xl font-mono py-8 h-24 tracking-[0.5em] rounded-xl border-2 border-primary/20 focus-visible:ring-primary bg-secondary/30"
                placeholder={step === "phone" ? "----------" : "------"}
              />
            </div>

            <div className="grid grid-cols-3 gap-4 mb-8">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <Button
                  key={num}
                  variant="outline"
                  className="h-20 text-3xl font-bold rounded-2xl hover:bg-primary/5 hover:border-primary transition-all"
                  onClick={() => handleNumberClick(num.toString())}
                >
                  {num}
                </Button>
              ))}
              <Button
                variant="ghost"
                className="h-20 text-xl font-medium rounded-2xl text-muted-foreground"
                onClick={() => setStep("phone")}
                disabled={step === "phone"}
              >
                Reset
              </Button>
              <Button
                variant="outline"
                className="h-20 text-3xl font-bold rounded-2xl hover:bg-primary/5 hover:border-primary transition-all"
                onClick={() => handleNumberClick("0")}
              >
                0
              </Button>
              <Button
                variant="ghost"
                className="h-20 rounded-2xl text-destructive hover:bg-destructive/10 hover:text-destructive transition-all"
                onClick={handleBackspace}
              >
                <Delete className="w-8 h-8" />
              </Button>
            </div>

            <Button 
              size="lg" 
              className="w-full h-20 text-2xl rounded-2xl gap-3 shadow-lg shadow-primary/20"
              onClick={handleSubmit}
              disabled={step === "phone" ? phoneNumber.length !== 10 : otp.length !== 6}
            >
              {step === "phone" ? "Send OTP" : "Verify & Login"}
              <ArrowRight className="w-6 h-6" />
            </Button>
          </div>
        ) : (
          <div className="w-full bg-white p-12 rounded-3xl shadow-lg border border-border flex flex-col items-center gap-8">
            <div className="w-64 h-64 bg-black rounded-2xl flex items-center justify-center relative overflow-hidden">
               <div className="absolute inset-0 border-4 border-primary z-10 animate-pulse"></div>
               <div className="w-full h-1 bg-red-500 absolute top-0 animate-[scan_2s_ease-in-out_infinite]"></div>
               <span className="text-white/50 text-lg">Camera View</span>
            </div>
            <p className="text-center text-muted-foreground text-lg max-w-sm">
              Point your kiosk scanner at the QR code on your mobile device
            </p>
             <Button 
              size="lg" 
              variant="outline"
              className="w-full h-16 text-xl rounded-2xl"
              onClick={() => setLocation("/dashboard")}
            >
              Simulate Scan Success
            </Button>
          </div>
        )}
      </div>
    </KioskLayout>
  );
}