import KioskLayout from "@/components/layout/KioskLayout";
import { Button } from "@/components/ui/button";
import { QrCode, Smartphone, UserPlus } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <KioskLayout showBackButton={false}>
      <div className="h-full flex flex-col justify-center items-center gap-12">
        <div className="text-center space-y-4 max-w-3xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-bold font-heading text-foreground tracking-tight"
          >
            Welcome to <span className="text-primary">SUVIDHA</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-2xl text-muted-foreground font-light"
          >
            Your one-stop digital kiosk for all civic services
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full max-w-5xl px-4">
          <Link href="/signup">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="h-72 rounded-3xl bg-white border-2 border-transparent hover:border-primary/20 shadow-lg hover:shadow-xl transition-all p-8 flex flex-col items-center justify-center gap-6 cursor-pointer group relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-primary text-white px-4 py-1 rounded-bl-xl font-medium text-sm">
                  New Citizen
                </div>
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                  <UserPlus className="w-10 h-10" />
                </div>
                <div className="text-center space-y-2">
                  <h3 className="text-2xl font-bold text-foreground">Sign Up</h3>
                  <p className="text-muted-foreground text-lg">Register using Aadhaar</p>
                </div>
              </div>
            </motion.div>
          </Link>

          <Link href="/login/mobile">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="h-72 rounded-3xl bg-white border-2 border-transparent hover:border-primary/20 shadow-lg hover:shadow-xl transition-all p-8 flex flex-col items-center justify-center gap-6 cursor-pointer group">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                  <Smartphone className="w-10 h-10" />
                </div>
                <div className="text-center space-y-2">
                  <h3 className="text-2xl font-bold text-foreground">Mobile Login</h3>
                  <p className="text-muted-foreground text-lg">Use phone number & OTP</p>
                </div>
              </div>
            </motion.div>
          </Link>

          <Link href="/login/qr">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="h-72 rounded-3xl bg-white border-2 border-transparent hover:border-accent/50 shadow-lg hover:shadow-xl transition-all p-8 flex flex-col items-center justify-center gap-6 cursor-pointer group relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-accent text-accent-foreground px-4 py-1 rounded-bl-xl font-medium text-sm">
                  Quick Access
                </div>
                <div className="w-24 h-24 bg-accent/10 rounded-full flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-colors">
                  <QrCode className="w-10 h-10" />
                </div>
                <div className="text-center space-y-2">
                  <h3 className="text-2xl font-bold text-foreground">Scan QR</h3>
                  <p className="text-muted-foreground text-lg">Login with Suvidha Pass</p>
                </div>
              </div>
            </motion.div>
          </Link>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-8"
        >
          <p className="text-muted-foreground text-lg flex items-center gap-2">
            Select your preferred language below or tap <span className="font-bold text-primary">Help</span> for assistance
          </p>
        </motion.div>
      </div>
    </KioskLayout>
  );
}