import KioskLayout from "@/components/layout/KioskLayout";
import { Zap, Droplets, Flame, Trash2, Construction, FileText, AlertTriangle, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

const services = [
  {
    id: "electricity",
    title: "Electricity",
    icon: Zap,
    color: "bg-yellow-500",
    description: "Bill payment, new connection, outages"
  },
  {
    id: "water",
    title: "Water Supply",
    icon: Droplets,
    color: "bg-blue-500",
    description: "Leakage, quality, new connection"
  },
  {
    id: "gas",
    title: "Gas Services",
    icon: Flame,
    color: "bg-orange-500",
    description: "Cylinder booking, leakage report"
  },
  {
    id: "waste",
    title: "Waste Mgmt",
    icon: Trash2,
    color: "bg-green-600",
    description: "Pickup issues, cleaning request"
  },
  {
    id: "infrastructure",
    title: "Public Works",
    icon: Construction,
    color: "bg-slate-600",
    description: "Roads, streetlights, drainage"
  },
  {
    id: "complaints",
    title: "My Complaints",
    icon: FileText,
    color: "bg-purple-600",
    description: "Track status, history"
  }
];

export default function Dashboard() {
  return (
    <KioskLayout>
      <div className="space-y-8 h-full flex flex-col">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-4xl font-bold font-heading text-foreground">Services Dashboard</h2>
            <p className="text-xl text-muted-foreground mt-2">Select a service to proceed</p>
          </div>
          
          <div className="bg-destructive/10 border border-destructive/20 text-destructive px-6 py-3 rounded-xl flex items-center gap-3 animate-pulse">
            <AlertTriangle className="h-6 w-6" />
            <span className="font-bold text-lg">High Alert: Heavy Rain Warning</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 flex-1 content-start">
          {services.map((service, index) => (
            <Link key={service.id} href={`/service/${service.id}`}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="group cursor-pointer h-full"
              >
                <div className="bg-white rounded-3xl p-6 h-full border-2 border-transparent hover:border-primary/20 shadow-md hover:shadow-xl transition-all flex flex-col justify-between">
                  <div className="flex items-start justify-between mb-6">
                    <div className={`w-16 h-16 rounded-2xl ${service.color} text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                      <service.icon className="w-8 h-8" />
                    </div>
                    <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <ChevronRight className="w-6 h-6 text-foreground" />
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-lg text-muted-foreground leading-snug">
                      {service.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </KioskLayout>
  );
}