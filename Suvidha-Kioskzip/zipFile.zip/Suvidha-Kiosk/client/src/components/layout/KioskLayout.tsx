import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Globe, Accessibility, ArrowLeft, HelpCircle, Home, User } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface KioskLayoutProps {
  children: React.ReactNode;
  showBackButton?: boolean;
}

export default function KioskLayout({ children, showBackButton = true }: KioskLayoutProps) {
  const [location, setLocation] = useLocation();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const isHome = location === "/";

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans overflow-hidden selection:bg-primary/20">
      {/* Top Bar */}
      <header className="h-20 bg-white border-b border-border flex items-center justify-between px-8 shadow-sm z-50 relative">
        <div className="flex items-center gap-4">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer group">
              <div className="bg-primary/10 p-2 rounded-lg group-hover:bg-primary/20 transition-colors">
                <img src="/logo.png" alt="Suvidha Logo" className="h-10 w-10 object-contain" />
              </div>
              <div className="flex flex-col">
                <h1 className="text-2xl font-bold font-heading text-primary leading-none tracking-tight">SUVIDHA</h1>
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Citizen Services</span>
              </div>
            </div>
          </Link>
        </div>

        <div className="flex items-center gap-4">
          <div className="bg-secondary/50 px-4 py-2 rounded-full text-lg font-medium text-foreground/80 font-mono">
            {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
          
          <Button variant="outline" size="lg" className="rounded-full gap-2 border-2 hover:bg-accent/10 hover:border-accent hover:text-accent-foreground transition-all">
            <Globe className="h-5 w-5" />
            <span className="text-lg">English</span>
          </Button>

          <Button variant="ghost" size="icon" className="rounded-full h-12 w-12 hover:bg-secondary">
            <Accessibility className="h-6 w-6" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 relative overflow-y-auto overflow-x-hidden bg-[url('/kiosk-bg.png')] bg-cover bg-center bg-fixed">
        <div className="absolute inset-0 bg-white/90 backdrop-blur-[2px]"></div>
        <div className="relative z-10 w-full h-full p-8 max-w-7xl mx-auto flex flex-col">
          {children}
        </div>
      </main>

      {/* Bottom Navigation */}
      <footer className="h-24 bg-white border-t border-border flex items-center justify-between px-8 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-50">
        <div className="flex items-center gap-4">
          {!isHome && showBackButton && (
            <Button 
              onClick={() => window.history.back()} 
              variant="secondary" 
              size="lg" 
              className="h-16 px-8 rounded-2xl text-xl gap-3 shadow-sm active:scale-95 transition-transform"
            >
              <ArrowLeft className="h-6 w-6" />
              Back
            </Button>
          )}
          
          {!isHome && (
            <Link href="/">
              <Button 
                variant="outline" 
                size="lg" 
                className="h-16 px-8 rounded-2xl text-xl gap-3 shadow-sm border-2 hover:bg-primary/5 hover:border-primary active:scale-95 transition-transform"
              >
                <Home className="h-6 w-6" />
                Home
              </Button>
            </Link>
          )}
        </div>

        <div className="flex items-center gap-4">
           <Button 
              variant="ghost" 
              size="lg" 
              className="h-16 px-8 rounded-2xl text-xl gap-3 text-muted-foreground hover:text-foreground"
            >
              <HelpCircle className="h-6 w-6" />
              Need Help?
            </Button>
        </div>
      </footer>
    </div>
  );
}