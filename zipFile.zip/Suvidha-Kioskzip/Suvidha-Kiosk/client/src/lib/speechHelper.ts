const audioCache = new Map<string, ArrayBuffer>();
const preloadingKeys = new Set<string>();
let audioCtx: AudioContext | null = null;
let currentSource: AudioBufferSourceNode | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx || audioCtx.state === "closed") {
    audioCtx = new AudioContext({ sampleRate: 24000 });
  }
  return audioCtx;
}

function pcm16ToFloat32(pcmBuffer: ArrayBuffer): Float32Array {
  const int16 = new Int16Array(pcmBuffer);
  const float32 = new Float32Array(int16.length);
  for (let i = 0; i < int16.length; i++) {
    float32[i] = int16[i] / 32768;
  }
  return float32;
}

function playPCM16(pcmBuffer: ArrayBuffer): Promise<void> {
  return new Promise((resolve) => {
    try {
      const ctx = getAudioContext();
      if (ctx.state === "suspended") {
        ctx.resume();
      }

      if (currentSource) {
        try { currentSource.stop(); } catch {}
      }

      const float32 = pcm16ToFloat32(pcmBuffer);
      const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => {
        currentSource = null;
        resolve();
      };
      currentSource = source;
      source.start();
    } catch {
      resolve();
    }
  });
}

export function stopSpeech() {
  if (currentSource) {
    try { currentSource.stop(); } catch {}
    currentSource = null;
  }
}

let pendingRequest: AbortController | null = null;

export async function speakText(text: string, lang?: string): Promise<void> {
  if (!text.trim()) return;

  if (pendingRequest) {
    pendingRequest.abort();
  }

  const cacheKey = `${text}::${lang || "en"}`;
  const cached = audioCache.get(cacheKey);
  if (cached) {
    await playPCM16(cached);
    return;
  }

  const controller = new AbortController();
  pendingRequest = controller;

  try {
    const res = await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, lang }),
      signal: controller.signal,
    });

    if (!res.ok) return;

    const buffer = await res.arrayBuffer();
    if (buffer.byteLength > 0) {
      audioCache.set(cacheKey, buffer);
      if (audioCache.size > 100) {
        const firstKey = audioCache.keys().next().value;
        if (firstKey) audioCache.delete(firstKey);
      }
      if (!controller.signal.aborted) {
        await playPCM16(buffer);
      }
    }
  } catch (e: any) {
    if (e?.name !== "AbortError") {
      console.error("TTS playback error:", e);
    }
  } finally {
    if (pendingRequest === controller) {
      pendingRequest = null;
    }
  }
}

export function preloadText(text: string, lang?: string): void {
  const cacheKey = `${text}::${lang || "en"}`;
  if (audioCache.has(cacheKey) || preloadingKeys.has(cacheKey)) return;
  preloadingKeys.add(cacheKey);
  fetch("/api/tts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text, lang }),
  })
    .then((res) => (res.ok ? res.arrayBuffer() : null))
    .then((buf) => {
      if (buf && buf.byteLength > 0) {
        audioCache.set(cacheKey, buf);
        if (audioCache.size > 100) {
          const firstKey = audioCache.keys().next().value;
          if (firstKey) audioCache.delete(firstKey);
        }
      }
    })
    .catch(() => {})
    .finally(() => preloadingKeys.delete(cacheKey));
}
